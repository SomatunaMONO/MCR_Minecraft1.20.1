import crafttweaker.api.recipe.IRecipeManager;
import crafttweaker.api.item.IItemStack;
import crafttweaker.api.ingredient.IIngredient;
import crafttweaker.api.data.IData;
import crafttweaker.api.util.random.Percentaged;
import crafttweaker.api.mod.Mods;
import mods.create.MechanicalCrafterManager;
import mods.create.SequencedAssemblyManager;

craftingTable.remove(<item:projecte:watch_of_flowing_time>);

var a=<item:projecte:dark_matter_block>;
var b=<item:projecte:red_matter>;
var c=<item:projecte:klein_star_omega>;
var d=<item:create:cuckoo_clock>;
var e=<item:mekanism_extras:alloy_shining>;
var f=<item:minecraft:nether_star>;
var g=<item:create:precision_mechanism>;
var h=<item:create:brass_casing>;
val n=<item:minecraft:air>;
<recipetype:create:mechanical_crafting>.addRecipe("antiziryuu", <item:projecte:watch_of_flowing_time>, 
[ [f,n,a,a,a,n,n],
  [n,a,b,e,b,a,n],
  [a,b,e,c,e,b,a],
  [a,e,c,d,c,e,a],
  [a,b,e,c,e,b,a],
  [n,a,b,e,b,a,n],
  [n,n,a,a,a,n,n]]);

  craftingTable.remove(d);
  <recipetype:create:mechanical_crafting>.addRecipe("hatokei", d, 
[ [n,h,h,h,n],
  [h,g,<item:minecraft:clock>,g,h],
  [h,<item:create:brass_sheet>,g,<item:create:brass_sheet>,h],
  [h,g,<item:create:brass_sheet>,g,h],
  [n,h,h,h,n]]);

var i=<item:create:blaze_cake>;
var j=<item:projecte:rm_furnace>;
var k=<item:projecte:watch_of_flowing_time>;
var l=<item:mekanism_extras:alloy_spectrum>;
  <recipetype:create:mechanical_crafting>.addRecipe("criecake", <item:create:creative_blaze_cake>, 
[ [n,n,i,i,i,i,i,n,n],
  [n,i,l,c,l,c,l,i,n],
  [i,l,c,k,j,k,c,l,i],
  [n,i,l,c,l,c,l,i,n],
  [n,n,i,i,i,i,i,n,n]]);
  var m= <item:create:creative_blaze_cake>;
  <recipetype:create:mechanical_crafting>.addRecipe("criemota", <item:create:creative_motor>, 
[ [n,h,h,h,l,h,h,h,n],
  [h,c,c,l,k,l,c,c,h],
  [h,c,k,l,g,l,k,c,h],
  [h,l,l,g,m,g,l,l,h],
  [l,k,g,m,m,m,g,k,l],
  [h,l,l,g,m,g,l,l,h],
  [h,c,k,l,g,l,k,c,h],
  [h,c,c,l,k,l,c,c,h],
  [n,h,h,h,l,h,h,h,n]]);
  craftingTable.addShaped("crietank", <item:create:creative_fluid_tank>, [
    [<item:create:fluid_tank>, <item:create:fluid_tank>,<item:create:fluid_tank>],
    [<item:create:fluid_tank>, <item:create:creative_motor>,<item:create:fluid_tank>],
    [<item:create:fluid_tank>, <item:create:fluid_tank>,<item:create:fluid_tank>]
    ]);

    val am01 =<item:minecraft:copper_ingot>;
    val am02 =<item:minecraft:gunpowder>;
    val am03 =<item:pointblank:processor>;
    val am04 =<item:pointblank:gunmetal_ingot>;
   
<recipetype:create:sequenced_assembly>.addRecipe(<recipetype:create:sequenced_assembly>.builder("creammo")
.transitionTo(k)
.require(k)
.loops(2048)
.addOutput(<item:pointblank:ammocreative>, 32)
.addStep<mods.createtweaker.DeployerApplicationRecipe>((rb) => rb.require(am01))
.addStep<mods.createtweaker.DeployerApplicationRecipe>((rb) => rb.require(am02))
.addStep<mods.createtweaker.DeployerApplicationRecipe>((rb) => rb.require(am03))
.addStep<mods.createtweaker.DeployerApplicationRecipe>((rb) => rb.require(am04))
.addStep<mods.createtweaker.DeployerApplicationRecipe>((rb) => rb.require(<item:projecte:dark_matter>))
);

var p= <item:create:creative_fluid_tank>;
var o= <item:create:item_vault>;
var q=<item:projecte:red_matter_block>;
var r=<item:pointblank:ammocreative>;
var s=<item:mekanism_extras:alloy_spectrum>;


e=<item:avaritia:neutronium_ingot>;
var u=<item:draconicevolution:large_chaos_frag>;
var v=<item:industrialforegoing:pink_slime_ingot>;
var w=<item:botania:life_essence>;
o =<item:avaritia:infinity_ingot>;
var y=<item:mekanism_extras:qio_drive_singularity>;
 <recipetype:create:mechanical_crafting>.addRecipe("createend", <item:create:creative_crate>, 
[ [o,o,o,o,o,o,l,o,o,o,o,o,o],
  [o,f,q,g,g,e,l,e,g,g,q,f,o],
  [o,q,g,q,e,l,m,l,e,q,g,q,o],
  [o,g,q,r,e,l,s,l,e,r,q,g,o],
  [o,g,e,e,l,s,u,s,l,e,e,g,o],
  [o,e,l,l,s,c,k,c,s,l,l,e,o],
  [l,l,m,s,w,k,p,k,v,s,m,l,l],
  [o,e,l,l,s,c,k,c,s,l,l,e,o],
  [o,g,e,e,l,s,y,s,l,e,e,g,o],
  [o,g,q,r,e,l,s,l,e,r,q,g,o],
  [o,q,g,q,e,l,m,l,e,q,g,q,o],
  [o,f,q,g,g,e,l,e,g,g,q,f,o],
  [o,o,o,o,o,o,l,o,o,o,o,o,o]]);







