val n = <item:minecraft:netherite_ingot>;
val b = <item:sophisticatedbackpacks:diamond_backpack>;
val d = <item:minecraft:diamond>;

val craftingResult = <item:sophisticatedbackpacks:netherite_backpack>;

val recipename = "easly_upgradebuckpack";

craftingTable.addShapeless(recipename, craftingResult,
    [ n, b, d ]
);